<?php

namespace Common\Files\Tus\Exceptions;

class FileException extends \RuntimeException
{
}
