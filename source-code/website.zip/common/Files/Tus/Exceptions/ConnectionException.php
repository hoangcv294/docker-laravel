<?php

namespace Common\Files\Tus\Exceptions;

class ConnectionException extends \Exception
{
}
